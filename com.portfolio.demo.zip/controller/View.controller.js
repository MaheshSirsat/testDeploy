sap.ui.define(["sap/ui/core/mvc/Controller"],function(o){"use strict";return o.extend("com.portfolio.demo.controller.View",{onInit:function(){}})});
//# sourceMappingURL=View.controller.js.map