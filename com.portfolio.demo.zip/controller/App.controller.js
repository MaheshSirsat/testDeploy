sap.ui.define(["sap/ui/core/mvc/Controller"],function(o){"use strict";return o.extend("com.portfolio.demo.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map